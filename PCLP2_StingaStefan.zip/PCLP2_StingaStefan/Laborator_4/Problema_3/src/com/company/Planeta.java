package com.company;

public class Planeta {
    public String nume;
    public int X, Y, Z;
    float media;
}
